#!/bin/bash

tar -xvzf cmake*.tar.gz
cd cmake-3.7.0-rc2/
./bootstrap
sudo make
sudo make install
sudo apt-get install libboost-all-dev -y
cd ../
unzip Poke*.zip
sudo cmake Exam/
sudo make
sudo chmod +x PokemonGame
./PokemonGame
